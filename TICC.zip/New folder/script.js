let currentPlayer = 'X';
let moves = ['', '', '', '', '', '', '', '', ''];
const winCombos = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

const boxes = document.querySelectorAll('.box');
const resultPopup = document.getElementById('result-popup');
const resultMessage = document.getElementById('result-message');

function playerMove(boxIndex) {
  if (!moves[boxIndex]) {
    moves[boxIndex] = currentPlayer;
    boxes[boxIndex].innerText = currentPlayer;
    if (checkWin()) {
      displayResult(currentPlayer + ' wins!');
    } else if (checkDraw()) {
      displayResult('It\'s a draw!');
    } else {
      currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
  }
}

function checkWin() {
  return winCombos.some(combo => {
    return combo.every(index => {
      return moves[index] === currentPlayer;
    });
  });
}

function checkDraw() {
  return moves.every(move => move !== '');
}

function displayResult(message) {
  resultMessage.innerText = message;
  resultPopup.style.display = 'flex';
}

function restartGame() {
  currentPlayer = 'X';
  moves = ['', '', '', '', '', '', '', '', ''];
  boxes.forEach(box => {
    box.innerText = '';
  });
  resultPopup.style.display = 'none';
}

// Add event listeners to each box
boxes.forEach((box, index) => {
  box.addEventListener('click', () => {
    playerMove(index);
  });
});
